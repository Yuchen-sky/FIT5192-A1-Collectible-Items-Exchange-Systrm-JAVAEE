/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fit5192.stu29184517;

import fit5192.stu29184517.repository.BuyOrderControl;
import fit5192.stu29184517.repository.CommodityControl;
import fit5192.stu29184517.repository.ExchangeControl;
import fit5192.stu29184517.repository.PossessionControl;
import fit5192.stu29184517.repository.SaleOrderControl;
import fit5192.stu29184517.repository.TypesControl;
import fit5192.stu29184517.repository.UsersControl;
import fit5192.stu29184517.repository.entities.BuyOrder;
import fit5192.stu29184517.repository.entities.Commodity;
import fit5192.stu29184517.repository.entities.Exchange;
import fit5192.stu29184517.repository.entities.Possession;
import fit5192.stu29184517.repository.entities.SaleOrder;
import fit5192.stu29184517.repository.entities.Types;
import fit5192.stu29184517.repository.entities.Users;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;

/**
 *
 * @author luzhe
 */
@Named(value = "commodityTrade")
@SessionScoped
public class CommodityTrade implements Serializable {

    @EJB
    private CommodityControl commodity_control;
    @EJB
    private SaleOrderControl sale_control;
    @EJB
    private BuyOrderControl buy_control;
    @EJB
    private TypesControl type_control;
    @EJB
    private ExchangeControl exchange_control;
     @EJB
     private UsersControl user_control;
     @EJB
     private PossessionControl po_control;
    /**
     * Creates a new instance of CommodityTrade
     */
    public CommodityTrade() {
    }

    private Commodity mainitem;
    int id;
    int orderid;
    int quantity;
    double perprice;
    String inform;
    String inform2;
    int buysalequantity;
    Users usinguser;

    public int getBuysalequantity() {
        return buysalequantity;
    }

    public void setBuysalequantity(int buysalequantity) {
        this.buysalequantity = buysalequantity;
    }

    public String getInform2() {
        return inform2;
    }

    public void setInform2(String inform2) {
        this.inform2 = inform2;
    }

    public String getInform() {
        return inform;
    }

    public void setInform(String inform) {
        this.inform = inform;
    }
    List<SaleOrder> saleorder;
    List<BuyOrder> buyorder;

    public List<SaleOrder> getSaleorder() {
        return saleorder;
    }

    public void setSaleorder(List<SaleOrder> saleorder) {
        this.saleorder = saleorder;
    }

    public List<BuyOrder> getBuyorder() {
        return buyorder;
    }

    public void setBuyorder(List<BuyOrder> buyorder) {
        this.buyorder = buyorder;
    }

    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPerprice() {
        return perprice;
    }

    public void setPerprice(double perprice) {
        this.perprice = perprice;
    }

    public String turnin(Commodity item) {
        if (item == null) {
            return "commoditylist";
        }
        mainitem = item;
        id = item.getCommodityId();
        return "commoditytrade";
    }

    public Commodity getMainitem() {
        return mainitem;
    }

    public void setMainitem(Commodity mainitem) {
        this.mainitem = mainitem;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Types> inititemtype() {
        List<Types> types = new ArrayList();
        types = type_control.findTypeByItem(id);;
        return types;

    }

    public List<SaleOrder> initsale() {
        List<SaleOrder> sale = new ArrayList();
        sale = sale_control.findSaleOrderByUser(id);
        saleorder=sale;
        return sale;

    }

    public List<BuyOrder> initbuy() {
        List<BuyOrder> buy = new ArrayList();
        buy = buy_control.findBuyOrderByUser(id);
        buyorder=buy;
        return buy;

    }

    @PostConstruct
    public void init() {
     usinguser=UserSave.INSTANCE.usersave;
    }
    
    public String publishsaleorder()throws Exception{
    SaleOrder sale=new SaleOrder();
    orderid= UUIDd();
    SaleOrder sale2=sale_control.findSaleOrder(orderid);
    if(sale2!=null){inform="Format is wrong or this id already exist."; 
    return "commoditytrade";}
    sale.setSaleOrderId(orderid);
    sale.setCommodityId(mainitem);
    sale.setOwnerId(UserSave.INSTANCE.usersave);
    sale.setQuantity(quantity);
    sale.setPerPrice(perprice*(1+mainitem.getTaxrate()));
    double price=perprice*quantity*(1+mainitem.getTaxrate());
    sale.setPrice(price);
    sale.setLock(false);
    sale_control.create(sale);  
    inform="sale order create successfully.";
    return "commoditytrade";
    }
    
    public String publishbuyorder()throws Exception{
    BuyOrder sale=new BuyOrder();
    orderid= UUIDd();
    BuyOrder sale2=buy_control.findBuyOrder(orderid);
    double price=perprice*quantity/(1+mainitem.getTaxrate());
    if(sale2!=null){inform="Format is wrong or this id already exist."; 
    return "commoditytrade";}
    if(UserSave.INSTANCE.usersave.getCredits()<(perprice*quantity)){inform="You have not enough credit to buy."; 
    return "commoditytrade";}
    
    sale.setBuyOrderId(orderid);
    sale.setCommodityId(mainitem);
    sale.setOwnerId(UserSave.INSTANCE.usersave);
    sale.setQuantity(quantity);
    sale.setPerPrice(perprice/(1+mainitem.getTaxrate()));   
    sale.setPrice(price);
    sale.setLock(false);
    buy_control.create(sale); 
    
    double cre=UserSave.INSTANCE.usersave.getCredits()-perprice*quantity;
    UserSave.INSTANCE.usersave.setCredits(cre);
    user_control.edit(UserSave.INSTANCE.usersave);
    usinguser=UserSave.INSTANCE.usersave;
    inform="buy order create successfully.";
    return "commoditytrade";
    }
    
    
   public String buy()throws Exception{
   SaleOrder order=saleorder.get(0);
   int canbuy=order.getQuantity();
   if(buysalequantity==canbuy&&UserSave.INSTANCE.usersave.getCredits()>=order.getPrice()){
   Exchange ex=new Exchange();
   short b=0;
   ex.setExchangeId(UUIDd());
   ex.setBuyOrSale(b);
   ex.setCommodityId(mainitem);
   ex.setExecuteUser(UserSave.INSTANCE.usersave);
   ex.setProvideUser(order.getOwnerId().getUserId());
   ex.setPerPrice(order.getPerPrice());
   ex.setPrice(order.getPrice());
   ex.setQuantity(buysalequantity);
   double price2=order.getPrice()/(1+mainitem.getTaxrate());
   ex.setNetProceed(order.getPrice()-price2);
   
   
   Possession po=new Possession();
   po.setCommodityId(mainitem);
   po.setPossessionId(UUIDd());
   po.setOwnerId(UserSave.INSTANCE.usersave);
   po.setProviderId(order.getOwnerId().getUserId());
   po.setExecuteStatus(0);
   po.setQuantity(buysalequantity);
   
   
   double credit=UserSave.INSTANCE.usersave.getCredits()-order.getPrice();
   UserSave.INSTANCE.usersave.setCredits(credit);
   Users saler=order.getOwnerId();
   double temp=saler.getCredits()+price2;
   saler.setCredits(temp);
   
   
   user_control.edit(saler);
   user_control.edit(UserSave.INSTANCE.usersave);
   usinguser=UserSave.INSTANCE.usersave;
   sale_control.destroy(order.getSaleOrderId());
   exchange_control.create(ex);
   po_control.create(po);
   inform2="buy successful.";
   return "commoditytrade";
   }
   else if(buysalequantity==canbuy&&UserSave.INSTANCE.usersave.getCredits()<order.getPrice()){
    inform2="you haven't enough credits.";
    return "commoditytrade";
   }
   else if(buysalequantity>canbuy){
       inform2="you can not buy such quantity at a time.";
       return "commoditytrade";
      
   }
   else if(buysalequantity<canbuy&&UserSave.INSTANCE.usersave.getCredits()<(buysalequantity*order.getPerPrice())){
    inform2="you haven't enough credits.";
    return "commoditytrade";
   
   }
   
   Exchange ex=new Exchange();
   short b=0;
   ex.setExchangeId(UUIDd());
   ex.setBuyOrSale(b);
   ex.setCommodityId(mainitem);
   ex.setExecuteUser(UserSave.INSTANCE.usersave);
   ex.setProvideUser(order.getOwnerId().getUserId());
   ex.setPerPrice(order.getPerPrice());
   ex.setPrice(buysalequantity*order.getPerPrice());
   ex.setQuantity(buysalequantity);
   double price2=buysalequantity*order.getPerPrice()/(1+mainitem.getTaxrate());
   ex.setNetProceed(buysalequantity*order.getPerPrice()-price2);
   
   
   Possession po=new Possession();
   po.setCommodityId(mainitem);
   po.setPossessionId(UUIDd());
   po.setOwnerId(UserSave.INSTANCE.usersave);
   po.setProviderId(order.getOwnerId().getUserId());
   po.setExecuteStatus(0);
   po.setQuantity(buysalequantity);
   
   order.setQuantity(canbuy-buysalequantity);
   order.setPrice(canbuy*order.getPerPrice());
   
   double credit=UserSave.INSTANCE.usersave.getCredits()-buysalequantity*order.getPerPrice();
   UserSave.INSTANCE.usersave.setCredits(credit);
   Users saler=order.getOwnerId();
   double temp=saler.getCredits()+price2;
   saler.setCredits(temp);
           
   user_control.edit(saler);
   user_control.edit(UserSave.INSTANCE.usersave);
   usinguser=UserSave.INSTANCE.usersave;
   sale_control.edit(order);
   exchange_control.create(ex);
   po_control.create(po);
   inform2="buy successful.";
     
   return "commoditytrade";
   }
    
   
   
   
   
   
   
   
   
   
   
   
  public String sale()throws Exception{
   BuyOrder order=buyorder.get(0);
   int cansale=order.getQuantity();
   if(buysalequantity==cansale){
   Exchange ex=new Exchange();
   short b=1;
   ex.setExchangeId(UUIDd());
   ex.setBuyOrSale(b);
   ex.setCommodityId(mainitem);
   ex.setExecuteUser(UserSave.INSTANCE.usersave);
   ex.setProvideUser(order.getOwnerId().getUserId());
   ex.setPerPrice(order.getPerPrice());
   ex.setPrice(order.getPrice());
   ex.setQuantity(buysalequantity);
   double price2=order.getPrice()*(1+mainitem.getTaxrate());
   ex.setNetProceed(price2-order.getPrice());
   
   
   Possession po=new Possession();
   po.setCommodityId(mainitem);
   po.setPossessionId(UUIDd());
   po.setOwnerId(order.getOwnerId());
   po.setProviderId(UserSave.INSTANCE.usersave.getUserId());
   po.setExecuteStatus(1);
   po.setQuantity(buysalequantity);
   
   
   double credit=UserSave.INSTANCE.usersave.getCredits()+order.getPrice();
   UserSave.INSTANCE.usersave.setCredits(credit);

   
   
   
   user_control.edit(UserSave.INSTANCE.usersave);
   usinguser=UserSave.INSTANCE.usersave;
   buy_control.destroy(order.getBuyOrderId());
   exchange_control.create(ex);
   po_control.create(po);
   inform2="sale successful.";
   return "commoditytrade";
   }
   
   else if(buysalequantity>cansale){
       inform2="you can not sale such quantity at a time.";
       return "commoditytrade";
      
   }
   Exchange ex=new Exchange();
   short b=1;
   ex.setExchangeId(UUIDd());
   ex.setBuyOrSale(b);
   ex.setCommodityId(mainitem);
   ex.setExecuteUser(UserSave.INSTANCE.usersave);
   ex.setProvideUser(order.getOwnerId().getUserId());
   ex.setPerPrice(order.getPerPrice());
   ex.setPrice(order.getPerPrice()*buysalequantity);
   ex.setQuantity(buysalequantity);
   double price2=order.getPerPrice()*buysalequantity*(1+mainitem.getTaxrate());
   ex.setNetProceed(price2-order.getPerPrice()*buysalequantity);
   
   
   Possession po=new Possession();
   po.setCommodityId(mainitem);
   po.setPossessionId(UUIDd());
   po.setOwnerId(order.getOwnerId());
   po.setProviderId(UserSave.INSTANCE.usersave.getUserId());
   po.setExecuteStatus(1);
   po.setQuantity(buysalequantity);
   
   
   double credit=UserSave.INSTANCE.usersave.getCredits()+order.getPerPrice()*buysalequantity;
   UserSave.INSTANCE.usersave.setCredits(credit);

   
   order.setQuantity(cansale-buysalequantity);
   order.setPrice(cansale*order.getPerPrice());
   
   user_control.edit(UserSave.INSTANCE.usersave);
   usinguser=UserSave.INSTANCE.usersave;
   buy_control.edit(order);
   exchange_control.create(ex);
   po_control.create(po);
   inform2="sale successful.";
   return "commoditytrade";
   
 
   }

    public Users getUsinguser() {
        return usinguser;
    }

    public void setUsinguser(Users usinguser) {
        this.usinguser = usinguser;
    }
   
   
   
   
 public int UUIDd() {
  int intUnbounded = new Random().nextInt();
  return intUnbounded;
}



    
}
