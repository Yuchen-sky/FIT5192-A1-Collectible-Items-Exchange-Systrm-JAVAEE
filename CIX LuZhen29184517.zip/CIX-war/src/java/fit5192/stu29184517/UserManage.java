/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fit5192.stu29184517;

import fit5192.stu29184517.repository.UsersControl;
import fit5192.stu29184517.repository.entities.Users;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;

/**
 *
 * @author luzhe
 */
@Named(value = "userManage")
@SessionScoped
public class UserManage implements Serializable {

    @EJB
    private UsersControl user_control;

    /**
     * Creates a new instance of UserManage
     */
    List<Users> users;
    List<Users> allusers;
    Users userchange;
    String inform;

    public String getInform() {
        return inform;
    }

    public void setInform(String inform) {
        this.inform = inform;
    }
    public Users getUserchange() {
        return userchange;
    }

    public void setUserchange(Users userchange) {
        this.userchange = userchange;
    }
    private int idin;
    private String lastin;
    private String firstin;
    private int phonein;
    private String emailin;
    int state;
    private int idin2;
    private String lastin2;
    private String firstin2;
    private int phonein2;
    private String emailin2;
    private String inform2;

    public String getInform2() {
        return inform2;
    }

    public void setInform2(String inform2) {
        this.inform2 = inform2;
    }
    
    
    
    public String unitsearch(){
       inform2=String.valueOf(idin2)+" "+lastin2+" "+firstin2 +"  "+String.valueOf(phonein2)+"  "+emailin2+" 0 means default, String null is default.";
        users=user_control.multifind(idin2, firstin2, lastin2, phonein2, emailin2);
        state=1;
       return "usercontrol";
    }
    
    
    public int getIdin2() {
        return idin2;
    }

    public void setIdin2(int idin2) {
        this.idin2 = idin2;
    }

    public String getLastin2() {
        return lastin2;
    }

    public void setLastin2(String lastin2) {
        this.lastin2 = lastin2;
    }

    public String getFirstin2() {
        return firstin2;
    }

    public void setFirstin2(String firstin2) {
        this.firstin2 = firstin2;
    }

    public int getPhonein2() {
        return phonein2;
    }

    public void setPhonein2(int phonein2) {
        this.phonein2 = phonein2;
    }

    public String getEmailin2() {
        return emailin2;
    }

    public void setEmailin2(String emailin2) {
        this.emailin2 = emailin2;
    }
    
    private int userid;
    private String email;
    private String password;
    private int level;
    private String first;
    private String last;
    private String address;
    private int phone;
    private double credit;
    private int virtue;

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getFirst() {
        return first;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public double getCredit() {
        return credit;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }

    public int getVirtue() {
        return virtue;
    }

    public void setVirtue(int virtue) {
        this.virtue = virtue;
    }
    
    

    public UserManage() {
        state = 0;
       
    }

   
    public List<Users> getUsers() {
        return users;
    }

    public void setUsers(List<Users> users) {
        this.users = users;
    }

    public int getIdin() {
        return idin;
    }

    public void setIdin(int idin) {
        this.idin = idin;
    }

    public String getLastin() {
        return lastin;
    }

    public void setLastin(String lastin) {
        this.lastin = lastin;
    }

    public String getFirstin() {
        return firstin;
    }

    public void setFirstin(String firstin) {
        this.firstin = firstin;
    }

    public int getPhonein() {
        return phonein;
    }

    public void setPhonein(int phonein) {
        this.phonein = phonein;
    }

    public String getEmailin() {
        return emailin;
    }

    public void setEmailin(String emailin) {
        this.emailin = emailin;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String viewAll() {
        this.users = user_control.findUsersEntities();

        state = 0;
        return "usermanage";
    }

    public String findById() {
        List<Users> users = new ArrayList();
        users.add(user_control.findUsers(idin));
        
        this.users = users;
        state = 1;
        
        return "usermanage";
    }

    public String findByFirst() {
        List<Users> users = user_control.findUsersFirst(firstin);
        if (users.size() == 1) {
            idin = users.get(0).getUserId();
        }
        this.users = users;
        state = 1;
        return "usermanage";
    }

    public String findByLast() {
        List<Users> users = user_control.findUsersLast(lastin);
        if (users.size() == 1) {
            idin = users.get(0).getUserId();
        }
        this.users = users;
        state = 1;
        return "usermanage";
    }

    public String findByPhone() {
        List<Users> users = user_control.findUsersPhone(phonein);
        if (users.size() == 1) {
            idin = users.get(0).getUserId();
        }
        this.users = users;
        state = 1;
        return "usermanage";
    }

    public String findByEmail() {
        List<Users> users = user_control.findUsersEmail(emailin);
        if (users.size() == 1) {
            idin = users.get(0).getUserId();
        }
        this.users = users;
        state = 1;
        return "usermanage";
    }
     public List<Users> initusers() {
        if (state == 1) {
            return this.users;
        }
        users = user_control.findUsersEntities();
        allusers=users;
        return this.users;
    }
@PostConstruct
public void init(){
    users = user_control.findUsersEntities();
       allusers=users;
    userid=0;
}

    
    public String userCreate() throws Exception{
     if(userid==0)return "";
     int flag=UserSave.INSTANCE.usersave.getMembershipLevel();
      if(flag!=2&&flag!=3){
            inform="you don't have right to do that."+String.valueOf(flag) ;
          return "usercontrol";}
   for(Users user:this.allusers){
    if(userid==user.getUserId()){inform="Format is wrong or this user already exist."; 
    return "usercontrol";}
    }
    Users userchange=new Users();
    userchange.setUserId(userid);
    userchange.setEmail(email);
    userchange.setPassword(password);
    userchange.setLastName(last);
    userchange.setFirstName(first);
    userchange.setMembershipLevel((short)level);
    userchange.setAddress(address);
    userchange.setPhoneNumber(phone);
    userchange.setCredits(credit);
    userchange.setTradingStatus((short)virtue);
    user_control.create(userchange);
    users.add(userchange);
    allusers.add(userchange);
    state = 1;
    return "usercontrol";
    }
    
    
     public String userUpdate() throws Exception{
     if(userid==0)return "";
     boolean flag2=true;
     int flag=UserSave.INSTANCE.usersave.getMembershipLevel();
      if(flag!=2&&flag!=3){
           inform="you don't have right to do that."+String.valueOf(flag) ;
          return "usercontrol";}
   for(Users user:this.allusers){
    if(userid==user.getUserId()){
        flag2=false;
        break;
    }
    }
   if(flag2==true){
       
      inform="Format is wrong or this user noexist."; 
   return "usercontrol";
   }
   
    Users userchange=new Users();
    userchange.setUserId(userid);
    userchange.setEmail(email);
    userchange.setPassword(password);
    userchange.setLastName(last);
    userchange.setFirstName(first);
    userchange.setMembershipLevel((short)level);
    userchange.setAddress(address);
    userchange.setPhoneNumber(phone);
    userchange.setCredits(credit);
    userchange.setTradingStatus((short)virtue);
    user_control.edit(userchange);
    state=0;
    return "usercontrol";
    }

    public String  userRemove(int removeid) throws Exception{
    
  
    if(removeid==1)return "usercontrol";
     int flag=UserSave.INSTANCE.usersave.getMembershipLevel();
      if(flag!=2&&flag!=3){
           inform="you don't have right to do that."+String.valueOf(flag) ;
          return "usercontrol";}
    user_control.destroy(removeid);
    state=0;
    inform="remove successful.";
     return "usercontrol";
    }
     
    
    
    
     
}
