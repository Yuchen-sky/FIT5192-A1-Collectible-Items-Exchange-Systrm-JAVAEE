/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fit5192.stu29184517;

import fit5192.stu29184517.repository.BuyOrderControl;
import fit5192.stu29184517.repository.CommodityControl;
import fit5192.stu29184517.repository.ExchangeControl;
import fit5192.stu29184517.repository.PossessionControl;
import fit5192.stu29184517.repository.SaleOrderControl;
import fit5192.stu29184517.repository.UsersControl;
import fit5192.stu29184517.repository.TypesControl;

import fit5192.stu29184517.repository.entities.BuyOrder;
import fit5192.stu29184517.repository.entities.Exchange;
import fit5192.stu29184517.repository.entities.Users;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;

/**
 *
 * @author luzhe
 */
@Named(value = "exBean")
@SessionScoped
public class exBean implements Serializable {

    /**
     * Creates a new instance of exBean
     */
     @EJB
    private CommodityControl commodity_control;
    @EJB
    private SaleOrderControl sale_control;
    @EJB
    private BuyOrderControl buy_control;
    @EJB
    private TypesControl type_control;
    @EJB
    private ExchangeControl exchange_control;
     @EJB
     private UsersControl user_control;
     @EJB
     private PossessionControl po_control;

    
    public exBean() {
        
    }
    
    @PostConstruct
    public void init(){
    state=0;
    executeuser=0;
    ex = exchange_control.findExchangeEntities();
    title="";
    exid=0;
    }
    
    int state;
    List<Exchange> ex;
    String title;
    int exid;
    int executeuser;
    String inform;

    public String getInform() {
        return inform;
    }

    public void setInform(String inform) {
        this.inform = inform;
    }
            
            
    public String exchange()
    {
      Users user=new Users();
    if(executeuser==0)user=null;
    else{user=user_control.findUsers(executeuser);}
    
  //  List<Exchange> output=new ArrayList();
    state=1;
    ex=exchange_control.findCommodityType(exid, title, user);
    
    inform=title+" "+String.valueOf(exid)+" "+String.valueOf(executeuser)+" 0 means default, title null is default.";
    return "exange";
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getExid() {
        return exid;
    }

    public void setExid(int exid) {
        this.exid = exid;
    }

    public int getExecuteuser() {
        return executeuser;
    }

    public void setExecuteuser(int executeuser) {
        this.executeuser = executeuser;
    }
    
    public List<Exchange> initexchange()
    {
      
       if(state==1)return this.ex;
       ex = exchange_control.findExchangeEntities(); 
       return ex;
        
        
    }
    
    public String viewAll(){
         ex = exchange_control.findExchangeEntities(); 
        
        state=0;
        return "exchange";
    }
    
}
