/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fit5192.stu29184517;

import fit5192.stu29184517.repository.entities.Users;

/**
 *
 * @author luzhe
 */
public enum UserSave {
    INSTANCE;
   public Users usersave;
}
