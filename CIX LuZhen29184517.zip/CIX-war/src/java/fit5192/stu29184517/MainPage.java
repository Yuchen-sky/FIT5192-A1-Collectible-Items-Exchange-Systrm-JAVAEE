/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fit5192.stu29184517;

import fit5192.stu29184517.repository.BuyOrderControl;
import fit5192.stu29184517.repository.CommodityControl;
import fit5192.stu29184517.repository.SaleOrderControl;
import fit5192.stu29184517.repository.TypesControl;
import fit5192.stu29184517.repository.entities.BuyOrder;
import fit5192.stu29184517.repository.entities.Commodity;
import fit5192.stu29184517.repository.entities.SaleOrder;
import fit5192.stu29184517.repository.entities.Types;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.enterprise.context.SessionScoped;

/**
 *
 * @author luzhe
 */
@Named(value = "mainPage")
@SessionScoped
public class MainPage implements Serializable{

    
    @EJB
    private CommodityControl commodity_control;
    @EJB
    private SaleOrderControl sale_control;
    @EJB
    private BuyOrderControl buy_control;
    @EJB
    private TypesControl type_control;
    
    private int idin;
    private String titlein;
    private String typein;
    List<Commodity> commodities;
    List<Commodity> allcommodities;
    List<Types> types;
    int state;
    /**
     * Creates a new instance of MainPage
     */
    public MainPage() {
     //  state=commodity_control.getCommodityCount();
     //   commodities=commodity_control.findCommodityEntities();
     //   types=type_control.findTypesEntities();
        state =0;
        idin=0;
        System.out.println("initial");
        
    }
    
    
    public List<Commodity> initcommodity(){
   if(state==1)return this.commodities;
    commodities=commodity_control.findCommodityEntities();
    allcommodities=commodities;
    return this.commodities;
   
   
    }
    
    public List<Types> inittype(){
    types=type_control.findTypesEntities();
    return this.types;
    }
    
    
    public  List<Types> inititemtype(){
    List<Types> types=new ArrayList();
     if(state==1&&commodities.size()==1)types=type_control.findTypeByItem(idin);;
    return types;
    
    
    }
    
    
    public  List<SaleOrder> initsale(){
    List<SaleOrder> sale=new ArrayList();
     if(state==1&&commodities.size()==1)sale=sale_control.findSaleOrderByUser(idin);
    return sale;
    
    
    }
    
    public  List<BuyOrder> initbuy(){
    List<BuyOrder> buy=new ArrayList();
     if(state==1&&commodities.size()==1)buy=buy_control.findBuyOrderByUser(idin);
    return buy;
    
    
    }
    

    public String viewAll(){
        this.commodities=commodity_control.findCommodityEntities();
         this.types=type_control.findTypesEntities();
        state=0;
        return "mainpage";
    }
    
    
    public List<Commodity> getCommodities() {
        return commodities;
    }

    public void setCommodities(List<Commodity> commodities) {
        this.commodities = commodities;
    }

    public List<Types> getTypes() {
        return types;
    }

    public void setTypes(List<Types> types) {
        this.types = types;
    }

    public int getIdin() {
        return idin;
    }

    public void setIdin(int idin) {
        this.idin = idin;
    }

    public String getTitlein() {
        return titlein;
    }

    public void setTitlein(String titlein) {
        this.titlein = titlein;
    }

    public String getTypein() {
        return typein;
    }

    public void setTypein(String typein) {
        this.typein = typein;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }
    
    
    public String findById(){
    List<Commodity> commodities=new ArrayList();
    commodities.add(commodity_control.findCommodity(idin));
     System.out.println(idin);
    this.commodities=commodities;
    state=1;
    System.out.println(state);
    return "mainpage";
    }
    
    public String findByTitle(){
     List<Commodity> commodities=commodity_control.findCommodityTitle(titlein);
    if(commodities.size()==1)idin=commodities.get(0).getCommodityId();
    this.commodities=commodities;
    state=1;
    return "mainpage";
    }
    
    public String findByType(){
    List<Commodity> commodities=commodity_control.findCommodityType(typein);
    if(commodities.size()==1)idin=commodities.get(0).getCommodityId();
    this.commodities=commodities;
    state=1;
    return "mainpage";
    }
    
    
    int id2;
    String title2;
    String image2;

    public int getId2() {
        return id2;
    }

    public void setId2(int id2) {
        this.id2 = id2;
    }

    public String getTitle2() {
        return title2;
    }

    public void setTitle2(String title2) {
        this.title2 = title2;
    }

    public String getImage2() {
        return image2;
    }

    public void setImage2(String image2) {
        this.image2 = image2;
    }

    public String getDes2() {
        return des2;
    }

    public void setDes2(String des2) {
        this.des2 = des2;
    }

    public String getPubli2() {
        return publi2;
    }

    public void setPubli2(String publi2) {
        this.publi2 = publi2;
    }

    public String getFeature2() {
        return feature2;
    }

    public void setFeature2(String feature2) {
        this.feature2 = feature2;
    }

    public String getQuality2() {
        return quality2;
    }

    public void setQuality2(String quality2) {
        this.quality2 = quality2;
    }

    public double getTaxrate2() {
        return taxrate2;
    }

    public void setTaxrate2(double taxrate2) {
        this.taxrate2 = taxrate2;
    }
    String des2;
    String publi2;
    String feature2;
    String quality2;
    double taxrate2;
    String inform;

    public String getInform() {
        return inform;
    }

    public void setInform(String inform) {
        this.inform = inform;
    }
    
    
   public String itemCreate() throws Exception{
    
   for(Commodity user:this.allcommodities){
    if(id2==user.getCommodityId()){inform="Format is wrong or commodity already exist."; 
    return "itemcontrol";}
    }
   if(title2==null){inform="format is wrong"; 
    return "itemcontrol";}
    
    Commodity userchange=new Commodity();
    userchange.setCommodityId(id2);
    userchange.setTitle(title2);
    userchange.setTaxrate(taxrate2);
    userchange.setStradingStatus((short)0);
    userchange.setSaleOrderNum(0);
    userchange.setDescription(des2);
    userchange.setQuality(quality2);
    userchange.setFeatures(feature2);
    userchange.setPublisher(publi2);
    userchange.setBuyOrderNum(0);
    userchange.setQuantity(0);
    userchange.setQuantityCirculation(0);
    userchange.setBuyOrderNum(0);
    
    commodity_control.create(userchange);
    commodities.add(userchange);
    allcommodities.add(userchange);
    state = 1;
    return "itemcontrol";
    }
    
}
