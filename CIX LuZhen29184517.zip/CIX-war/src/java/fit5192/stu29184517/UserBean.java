/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fit5192.stu29184517;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import fit5192.stu29184517.repository.UsersControl;
import fit5192.stu29184517.repository.entities.Users;
import javax.ejb.EJB;
/**
 *
 * @author luzhe
 */
@Named(value = "userBean")
@SessionScoped
public class UserBean implements Serializable {

    
    @EJB
     private  UsersControl user_control;
    
    /**
     * Creates a new instance of UserBean
     */
    public UserBean() {
    }
    private String Email;
    private String Password;
    private Users user;

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        System.out.println(Email);
        this.Email = Email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        System.out.println(Password);
        this.Password = Password;
    }
    
   public String validation(){
   
       Users user=user_control.findUsersByEmail(this.Email, this.Password);
        
        if(user==null){
          System.out.println("null");
          return "loginfail";
        }
        System.out.println(user.getPassword());
        this.user=user;
        UserSave.INSTANCE.usersave=user; 
        return "profile";
   } 
   
   public String showPower(){
   int level=this.user.getMembershipLevel();
   if(level==1)return "Trader";
   if(level==2)return "Administrator";
   if(level==3)return"Super-Administrator";
   return "Visitor";
   }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }
    
    
  public boolean judge(){
     int temp=UserSave.INSTANCE.usersave.getMembershipLevel();
     if(temp==2||temp==3)return true;
     return false;
  
  }
    
    
}
