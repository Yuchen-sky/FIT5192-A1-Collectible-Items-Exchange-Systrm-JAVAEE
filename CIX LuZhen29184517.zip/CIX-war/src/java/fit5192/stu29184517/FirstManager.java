/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fit5192.stu29184517;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;

/**
 *
 * @author luzhe
 */
@Named(value = "firstManager")
@SessionScoped
public class FirstManager implements Serializable {

    /**
     * Creates a new instance of FirstManager
     */
    private int age;
    private String message;
    private String name;
 private static final int  DEFAULT_AGE=18;
    
    /**
     * Creates a new instance of PersonBean
     */
    public FirstManager() {
        age=DEFAULT_AGE;
        message="";
        name="";
        
    }
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
}
